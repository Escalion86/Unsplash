import PhotoCard from './photoCard';
export default PhotoCard;