import PhotoList from './photoList';
export default PhotoList;